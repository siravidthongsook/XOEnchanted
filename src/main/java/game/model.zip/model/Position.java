package game.model;

public record Position(int row, int col) {
}
