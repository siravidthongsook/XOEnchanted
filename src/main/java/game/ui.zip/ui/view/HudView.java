package game.ui.view;

import game.model.GameState;
import game.model.PlayerId;
import game.ui.SkillMode;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;

public class HudView {
    private final BorderPane node;
    private final HBox scoreXBox;
    private final HBox energyXBox;
    private final HBox scoreOBox;
    private final HBox energyOBox;
    private final Label statusLabel;
    private final Label modeLabel;

    public HudView() {
        // Player X (ด้านซ้าย)
        Label xIcon = new Label();
        xIcon.getStyleClass().addAll("piece-x", "top-icon");
        scoreXBox = new HBox(4);
        energyXBox = new HBox(4);
        VBox xBars = new VBox(6, scoreXBox, energyXBox);
        xBars.setAlignment(Pos.CENTER_LEFT);
        HBox xPlayerStats = new HBox(15, xIcon, xBars);
        xPlayerStats.setAlignment(Pos.CENTER_LEFT);

        // Player O (ด้านขวา)
        Label oIcon = new Label();
        oIcon.getStyleClass().addAll("piece-o", "top-icon");
        scoreOBox = new HBox(4);
        energyOBox = new HBox(4);
        VBox oBars = new VBox(6, scoreOBox, energyOBox);
        oBars.setAlignment(Pos.CENTER_RIGHT);
        HBox oPlayerStats = new HBox(15, oBars, oIcon);
        oPlayerStats.setAlignment(Pos.CENTER_RIGHT);

        // Center Info (โหมดเกมและ Log ข้อความ)
        modeLabel = new Label("MODE: PLACE");
        modeLabel.getStyleClass().add("hud-value");
        statusLabel = new Label("");
        statusLabel.getStyleClass().add("status-label");
        VBox centerBox = new VBox(5, modeLabel, statusLabel);
        centerBox.setAlignment(Pos.CENTER);

        node = new BorderPane();
        node.setLeft(xPlayerStats);
        node.setCenter(centerBox);
        node.setRight(oPlayerStats);
        node.getStyleClass().add("top-hud-container");
    }

    public BorderPane node() {
        return node;
    }

    public void showStatus(String status) {
        statusLabel.setText(status);
    }

    public void showPlacedAt(int row, int col) {
        statusLabel.setText("Placed at (" + row + ", " + col + ")");
    }

    public void render(GameState state, SkillMode mode) {
        modeLabel.setText("MODE: " + mode.name());

        // แยกกำหนดจำนวนช่องสูงสุดของ Score และ Energy
        int maxScore = 5;   // ช่องคะแนน 5 ช่อง (ปรับลดได้ถ้าชนะเร็วกว่านี้)
        int maxEnergy = 10; // ช่องพลังงาน 10 ช่องตามที่ต้องการ

        // อัปเดตหลอดของ Player X
        updateBars(scoreXBox, state.getPlayerState(PlayerId.X).getScore(), maxScore);
        updateBars(energyXBox, state.getPlayerState(PlayerId.X).getEnergy(), maxEnergy);

        // อัปเดตหลอดของ Player O
        updateBars(scoreOBox, state.getPlayerState(PlayerId.O).getScore(), maxScore);
        updateBars(energyOBox, state.getPlayerState(PlayerId.O).getEnergy(), maxEnergy);

        if (state.isGameOver()) {
            statusLabel.setText("GAME OVER! WINNER: " + state.getWinner());
            statusLabel.setStyle("-fx-text-fill: yellow;");
        } else if (state.isSuddenDeath()) {
            statusLabel.setText("SUDDEN DEATH ACTIVE!");
            statusLabel.setStyle("-fx-text-fill: orange;");
        }
    }

    private void updateBars(HBox container, int currentVal, int maxVal) {
        container.getChildren().clear();

        // ป้องกันไม่ให้วาดเกินจำนวนช่องสูงสุดในกรณีที่ค่า Energy หรือ Score ล้น
        int displayVal = Math.min(currentVal, maxVal);

        for (int i = 0; i < maxVal; i++) {
            Region block = new Region();
            block.getStyleClass().add("stat-block");

            // เช็คและถมสีให้เฉพาะช่องที่มีค่าไม่เกิน displayVal
            if (i < displayVal) {
                block.getStyleClass().add("stat-block-filled");
            }
            container.getChildren().add(block);
        }
    }
}