package game.ui.view;

import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;

public class ActionBarView {
    private final VBox node;

    public ActionBarView(
            Runnable onSeal,
            Runnable onShift,
            Runnable onDisrupt,
            Runnable onDoublePlace,
            Runnable onReset
    ) {
        Label titleLabel = new Label("XO ENCHANTED");
        titleLabel.getStyleClass().add("header-label");

        Button sealButton = new Button("SEAL");
        Button shiftButton = new Button("SHIFT");
        Button disruptButton = new Button("DISRUPT");
        Button doublePlaceButton = new Button("DOUBLE PLACE");
        Button resetButton = new Button("RESET");

        sealButton.setOnAction(event -> onSeal.run());
        shiftButton.setOnAction(event -> onShift.run());
        disruptButton.setOnAction(event -> onDisrupt.run());
        doublePlaceButton.setOnAction(event -> onDoublePlace.run());
        resetButton.setOnAction(event -> onReset.run());

        // กล่องรวมปุ่ม
        VBox buttonBox = new VBox(25, sealButton, shiftButton, disruptButton, doublePlaceButton, resetButton);
        buttonBox.setAlignment(Pos.CENTER);
        buttonBox.getStyleClass().add("action-button-box");

        // สร้างกรอบของกล่องปุ่มที่มีเครื่องหมาย + ตามมุม (ทำผ่าน StackPane)
        StackPane boxWrapper = new StackPane();
        Label tl = new Label("+"); tl.getStyleClass().add("corner-plus");
        Label tr = new Label("+"); tr.getStyleClass().add("corner-plus");
        Label bl = new Label("+"); bl.getStyleClass().add("corner-plus");
        Label br = new Label("+"); br.getStyleClass().add("corner-plus");

        StackPane.setAlignment(tl, Pos.TOP_LEFT);
        StackPane.setAlignment(tr, Pos.TOP_RIGHT);
        StackPane.setAlignment(bl, Pos.BOTTOM_LEFT);
        StackPane.setAlignment(br, Pos.BOTTOM_RIGHT);

        boxWrapper.getChildren().addAll(buttonBox, tl, tr, bl, br);

        this.node = new VBox(40, titleLabel, boxWrapper);
        this.node.getStyleClass().add("right-panel-container");
        this.node.setAlignment(Pos.TOP_CENTER);
    }

    public VBox node() {
        return node;
    }
}