package game.ui;

public enum SkillMode {
    PLACE,
    SEAL,
    SHIFT,
    DISRUPT,
    DOUBLE_PLACE
}
